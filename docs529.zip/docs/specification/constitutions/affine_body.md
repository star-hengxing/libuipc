# Affine Body

This page registers the Affine Body constitution.