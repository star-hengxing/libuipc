# Constitutions

| UID | Friendly Name                  | Description                         |
| --- | ------------------------------ | ----------------------------------- |
| 0   | Empty                          | Preserved                           |
| 1-8 | [AffineBody](./affine_body.md) | Affine Body Preserved Constitutions |