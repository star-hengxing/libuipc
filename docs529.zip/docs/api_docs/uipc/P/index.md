---
title: P
description: A different version of weak pointer that allows for easier access to the underlying object 
generator: doxide
---


# P

**template &lt;typename T&gt; class P : public std::weak_ptr&lt;T&gt;**



A different version of weak pointer that allows for easier access to the underlying object
 




