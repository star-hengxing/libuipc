---
title: uipc
description: 
generator: doxide
---


# uipc



:material-package: [builtin](builtin/index.md)
:   

:material-package: [geometry](geometry/index.md)
:   

## Types

| Name | Description |
| ---- | ----------- |
| [P](P/index.md) | A different version of weak pointer that allows for easier access to the underlying object  |

