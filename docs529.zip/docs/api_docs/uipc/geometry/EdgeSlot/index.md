---
title: EdgeSlot
description: Alias for a slot for edges in an abstract simplicial complex. 
generator: doxide
---


# EdgeSlot

**using EdgeSlot = SimplexSlot&lt;1&gt;**



Alias for a slot for edges in an abstract simplicial complex.
 




