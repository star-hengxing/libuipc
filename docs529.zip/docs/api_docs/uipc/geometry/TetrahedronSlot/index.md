---
title: TetrahedronSlot
description: Alias for a slot for tetrahedra in an abstract simplicial complex. 
generator: doxide
---


# TetrahedronSlot

**using TetrahedronSlot = SimplexSlot&lt;3&gt;**



Alias for a slot for tetrahedra in an abstract simplicial complex.
 




