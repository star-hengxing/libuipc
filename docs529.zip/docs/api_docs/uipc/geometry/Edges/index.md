---
title: Edges
description: A collection of edges.
generator: doxide
---


# Edges

**using Edges = Simplices&lt;1&gt;**



A collection of edges.

$E=\{(i,j) \mid i,j\in V, i\neq j\}$, where $V$ is the set of vertices.



