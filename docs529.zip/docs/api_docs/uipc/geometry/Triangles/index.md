---
title: Triangles
description: A collection of triangles.
generator: doxide
---


# Triangles

**using Triangles = Simplices&lt;2&gt;**



A collection of triangles.

$F=\{(i,j,k) \mid i,j,k\in V, i\neq j\neq k\}$, where $V$ is the set of vertices.



