---
title: TriangleSlot
description: Alias for a slot for triangles in an abstract simplicial complex. 
generator: doxide
---


# TriangleSlot

**using TriangleSlot = SimplexSlot&lt;2&gt;**



Alias for a slot for triangles in an abstract simplicial complex.
 




