---
title: Vertices
description: A collection of vertices.
generator: doxide
---


# Vertices

**class Vertices final : public ISimplices**



A collection of vertices.

$V=\{0,1,2,...,N-1\}$, where $N$ is the number of vertices.
Normally, we don't store the vertice indices, because the indices is just iota $[0, N)$.



## Functions

| Name | Description |
| ---- | ----------- |
| [view](#view) | Get the const view of the vertices  |
| [view](#view) | Get the non-const view of the vertices  |

## Function Details

### view<a name="view"></a>
!!! function "[[nodiscard]] span&lt;const IndexT&gt; view() const"

    
    
    Get the const view of the vertices
         
    
    
    

!!! function "span&lt;IndexT&gt; view(Vertices&amp; vertices) noexcept"

    
    
    Get the non-const view of the vertices
         
    
    
    

