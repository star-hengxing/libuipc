---
title: EdgeAttributes
description: Alias for the edge attributes
generator: doxide
---


# EdgeAttributes

**using EdgeAttributes = SimplicialComplexAttributes&lt;EdgeSlot&gt;**



Alias for the edge attributes

:material-eye-outline: **See**
:    [SimplicialComplexAttributes](../../SimplicialComplexAttributes/)



