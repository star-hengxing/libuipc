---
title: TetrahedronAttributes
description: Alias for the tetrahedron attributes
generator: doxide
---


# TetrahedronAttributes

**using TetrahedronAttributes = SimplicialComplexAttributes&lt;TetrahedronSlot&gt;**



Alias for the tetrahedron attributes

:material-eye-outline: **See**
:    [SimplicialComplexAttributes](../../SimplicialComplexAttributes/)



