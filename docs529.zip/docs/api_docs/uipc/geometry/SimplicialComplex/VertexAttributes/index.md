---
title: VertexAttributes
description: Alias for the vertex attributes
generator: doxide
---


# VertexAttributes

**using VertexAttributes = SimplicialComplexAttributes&lt;VertexSlot&gt;**



Alias for the vertex attributes

:material-eye-outline: **See**
:    [SimplicialComplexAttributes](../../SimplicialComplexAttributes/)



