---
title: TriangleAttributes
description: Alias for the triangle attributes
generator: doxide
---


# TriangleAttributes

**using TriangleAttributes = SimplicialComplexAttributes&lt;TriangleSlot&gt;**



Alias for the triangle attributes

:material-eye-outline: **See**
:    [SimplicialComplexAttributes](../../SimplicialComplexAttributes/)



