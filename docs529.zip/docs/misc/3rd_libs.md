# fmt

- [Format User Type](https://fmt.dev/latest/api.html?highlight=custom#formatting-user-defined-types)